package com.webtoapp.generated

object AppConfig {
    const val APP_NAME = "Busya шумомер (децибелы)"
    const val TARGET_URL = ""

    const val ACTIVATION_ENABLED = false
    val ACTIVATION_CODES = listOf()

    const val AD_BLOCK_ENABLED = false
    val AD_BLOCK_RULES = listOf()

    const val ANNOUNCEMENT_ENABLED = true
    const val ANNOUNCEMENT_TITLE = "ВНИМАНИЕ!"
    const val ANNOUNCEMENT_CONTENT = "Разрешение на микрофон требуется исключительно для работы шумомера. Ваши разговоры не отправляются в сеть. Политика конфиденциальности - https://delicate-bavarois-a8defa.netlify.app/"
    const val ANNOUNCEMENT_LINK = "https://delicate-bavarois-a8defa.netlify.app/"
    const val ANNOUNCEMENT_SHOW_ONCE = true

    const val JAVASCRIPT_ENABLED = true
    const val DOM_STORAGE_ENABLED = true
    const val ZOOM_ENABLED = true
    const val DESKTOP_MODE = false
}